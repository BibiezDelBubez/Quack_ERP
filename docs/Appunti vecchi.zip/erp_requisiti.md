# ERP Prodotti Chimici — Requisiti e Decisioni di Progettazione

## Contesto

Web app da girare solo in locale. Piccolo ERP per la vendita di prodotti chimici, spesso ADR (merci pericolose). Prodotti principali: chimici per piscina. Il DB è SQLite nel prototipo, MySQL in futuro. Nessun framework ERP esterno — sviluppo custom.

---

## Moduli richiesti

### 1. Anagrafica clienti e fornitori
- Tabella unica `clienti_fornitori` per i dati comuni (ragione sociale, P.IVA, CF, email, telefono, cellulare, fax, PEC, sito web)
- Tabella `dettagli_clienti` in relazione 1:1 per i dati specifici cliente (tipo cliente, canale vendita, listino, sconto extra, condizioni pagamento, fido credito, SDI, regime fiscale, IVA esente, zona commerciale)
- Tabella `dettagli_fornitori` in relazione 1:1 per i dati specifici fornitore (tipo fornitore, lead time, MOQ in € e kg, codice cliente presso fornitore, portale ordini, certificazione ADR con numero e scadenza, REACH)
- Tabella `indirizzi` con FK pulita verso `clienti_fornitori` (un soggetto può avere N indirizzi di tipo diverso: sede legale, operativa, spedizione, fatturazione, magazzino)
- Un soggetto può essere sia cliente che fornitore contemporaneamente (campo `tipo` con valore 'entrambi')
- Tabella `tipi_fornitore` come lookup (produttore, distributore, dropshipper…) con flag `gestisce_magazzino` per logica stock
- Tabelle `contatti` e `agenti` escluse dal prototipo
- Codice cliente/fornitore generato automaticamente con possibilità di override manuale
- Condizioni di pagamento come testo libero sull'anagrafica (default) con override sulla singola offerta

### 2. Prodotti
- Tabella `prodotti` per il prodotto astratto (nome, SKU interno, descrizione, tipo, categoria, dati ADR)
- Tabella `varianti_prodotto` per le unità concrete vendibili/stoccabili (SKU variante, descrizione confezione, unità di misura, quantità confezione in kg/l, peso netto, peso lordo, EAN). Ogni prodotto può avere più varianti — es. stesso prodotto in confezioni da 5kg, 10kg, 25kg
- Il prezzo è sempre espresso per unità di misura base (€/kg o €/litro), mai per confezione. La conversione al totale confezione è logica applicativa
- Tabella `categorie` ad albero gerarchico (parent_id autoreferenziale). Un prodotto appartiene a una sola categoria
- Tabella `tag` e tabella ponte `prodotti_tag` many-to-many. Differenza con categorie: le categorie sono struttura gerarchica di navigazione ("dove si trova il prodotto"), i tag sono etichette trasversali libere ("cosa è il prodotto")
- Tabella `kit_componenti` per prodotti di tipo 'kit' (bundle di varianti con quantità)
- Tabella `prodotti_fornitori` per collegare varianti ai fornitori: contiene SKU fornitore, nome fornitore, prezzo di acquisto (€/kg), prezzo minimo consigliato (€/kg), prezzo massimo consigliato (€/kg), MOQ, flag preferenziale. Il min/max è una raccomandazione del fornitore per il canale dropshipping
- Tabella `adr_sostanze` con numero ONU come PK (dati fissi da normativa: descrizione ufficiale, classe ADR, note). Il prodotto ha FK verso questa tabella + campo `adr_packing_group` proprio perché può variare per stesso numero ONU
- Tabella `safety_data_sheets` (schede di sicurezza) collegata al prodotto (non alla variante): lingua ISO 639-2, data revisione, percorso file, flag is_active. Più versioni per lingua, una sola attiva
- Tabella `product_images` collegata alla variante (non al prodotto): percorso file, sort_order per galleria

### 3. Magazzino
- La giacenza NON è un campo statico sul prodotto
- Tabella `movimenti_magazzino`: registro immutabile. Ogni evento (carico, scarico, reso cliente, reso fornitore, rettifica, riservazione, svincolo) è una riga. Non si modifica mai, si aggiunge solo. Contiene tipo movimento, quantità (positiva o negativa), riferimento al documento di origine, canale origine (erp/woocommerce/manuale), riferimento esterno (es. WooCommerce order ID per anti-duplicazione)
- Tabella `giacenze`: snapshot aggiornato per performance (quantità disponibile, riservata, in arrivo, scorta minima). Una riga per variante. Aggiornata da ogni movimento
- Inventario fisico: l'utente inserisce la quantità contata, il sistema calcola la rettifica (quantita_contata - giacenza_teorica) e inserisce un movimento di tipo 'rettifica'
- Tabella `inventari` (testata: data, note, utente) + `inventari_righe` (per ogni prodotto: giacenza teorica snapshot, quantità contata, rettifica calcolata, FK al movimento generato)
- Integrazione futura con WooCommerce: il campo `canale_origine` e `riferimento_esterno` in `movimenti_magazzino` sono già predisposti. L'ERP è il master del magazzino, WooCommerce si adegua via API/webhook

### 4. Pricing — Listini
- Tabella `listini` con campi `canale_vendita` e `tipo_cliente` (entrambi nullable = si applica a tutti). Permette di avere listini per combinazione canale+tipo cliente
- Tabella `listini_prezzi`: prezzo per variante con scaglioni di quantità (campo `quantita_minima`). Prezzo espresso in €/kg. Alternativa tra prezzo fisso e sconto percentuale sul base
- Canali di vendita: sito, email_diretta, dropshipping, agente
- Tipi cliente: end_user, rivenditore, dropshipper, grossista, ente_pubblico
- Sul cliente è assegnato un listino di default, override possibile sulla singola offerta

### 5. Offerte
- Numero offerta generato automaticamente (es. OFF-2026-0042)
- Campi testata: cliente, indirizzo spedizione, alla c.a. (testo libero), data offerta, data scadenza, data consegna richiesta, canale vendita, stato, listino usato, sconto globale %, condizioni pagamento, trasporto, valuta
- Stati: bozza, inviata, accettata, rifiutata, scaduta, annullata
- Tabella `offerte_storico_stati` per tracciare ogni cambio di stato con note e utente
- Righe offerta (`offerte_righe`): variante (nullable per righe testo libero come spese trasporto), descrizione copiata al momento (non cambia se il prodotto viene rinominato dopo), quantità in confezioni, prezzo unitario €/kg (precompilato dal listino, modificabile), sconto %, prezzo netto, aliquota IVA, totale riga, costo unitario (copiato da prodotti_fornitori al momento — snapshot), totale costo riga, margine riga (= DELTA nel prototipo), flag is_adr, sort_order
- Totali su testata offerta: imponibile, totale IVA, totale, totale costo, margine €, margine % — salvati al momento della conferma come snapshot (non cambiano se i prezzi cambiano dopo)
- Stampa offerta in DOCX

### 6. Sistema
- Tabella `utenti` con ruoli: admin, commerciale, magazziniere, readonly
- Password con bcrypt, mai in chiaro

---

## Decisioni architetturali prese

| Tema | Scelta | Motivazione |
|---|---|---|
| Anagrafica unica vs separata | Tabella unica + dettagli separati (class table inheritance) | Gestisce soggetti che sono sia clienti che fornitori; FK pulita per indirizzi |
| Indirizzi | Tabella separata con FK verso clienti_fornitori | Un soggetto può avere N indirizzi di tipo diverso |
| Codice cliente/fornitore | Auto-generato con override | Compatibilità con sistemi esterni |
| Giacenza magazzino | Registro movimenti + snapshot giacenze | Storico, tracciabilità, rettifiche senza perdita dati |
| Rettifica inventario | L'utente inserisce il contato, il sistema calcola il delta | Flusso naturale per chi fa l'inventario fisico |
| Prezzo per unità | Sempre €/kg o €/unità di misura base | I fornitori quotano per kg, le confezioni cambiano, i margini sono comparabili |
| Min/Max prezzo | In prodotti_fornitori come raccomandazione del fornitore | Non è un fatto del listino ma del rapporto fornitore-prodotto |
| Totali offerta | Salvati come snapshot sulla testata | I documenti storici non cambiano al cambio prezzi |
| Integrazione WooCommerce | canale_origine + riferimento_esterno in movimenti_magazzino | ERP master, WooCommerce slave; anti-duplicazione ordini |
| Tabelle escluse dal prototipo | contatti, agenti | Semplificazione — aggiungibili in futuro |

---

## Tabelle — elenco completo (25 tabelle)

### Anagrafica
- clienti_fornitori
- dettagli_clienti
- dettagli_fornitori
- indirizzi
- tipi_fornitore *(lookup)*

### Prodotti
- prodotti
- varianti_prodotto
- categorie
- tag
- prodotti_tag
- adr_sostanze
- kit_componenti
- prodotti_fornitori
- safety_data_sheets
- product_images

### Magazzino
- giacenze
- movimenti_magazzino
- inventari
- inventari_righe

### Pricing e Offerte
- listini
- listini_prezzi
- offerte
- offerte_righe
- offerte_storico_stati

### Sistema
- utenti

---

## Moduli non ancora progettati (da fare in futuro)
- DDT (documenti di trasporto)
- Ordini di acquisto ai fornitori
- Fatturazione
- Report e statistiche
