# Prompt di partenza — ERP Prodotti Chimici



Devo progettare il database per una web app da girare solo in locale. È un piccolo ERP per la nostra azienda che vende prodotti chimici, spesso ADR (merci pericolose). Il prodotto principale sono chimici per piscina.



Il DB sarà SQLite nel prototipo e MySQL in futuro. Voglio uno schema professionale ma non over-engineered — l'obiettivo è trovare un equilibrio tra professionalità (best practice) e versatilità.



Motiva ogni decisione.





\---



## Cosa deve fare il sistema



### Anagrafica clienti e fornitori



* Gestire sia clienti che fornitori nella stessa struttura, tenendo conto che uno stesso soggetto può essere sia cliente che fornitore
* I clienti hanno informazioni specifiche (tipo cliente, canale di vendita, listino assegnato, condizioni di pagamento, fido, dati per fatturazione elettronica italiana come codice SDI e regime fiscale)
* I fornitori hanno informazioni specifiche (tipo fornitore, tempi di consegna, quantità minime d'ordine, certificazione ADR con scadenza, registrazione REACH)
* Ogni soggetto può avere più indirizzi di tipo diverso (sede legale, spedizione, magazzino, ecc.)
* I codici cliente/fornitore devono essere generati automaticamente ma modificabili manualmente
* Le condizioni di pagamento sono un default sull'anagrafica ma possono essere cambiate sulla singola offerta



### Prodotti



* Anagrafica prodotti con nome, SKU interno, descrizione, foto, categoria, tag
* Lo stesso prodotto può essere fornito da più fornitori, ognuno con il proprio SKU e nome commerciale
* I prodotti possono esistere in confezioni diverse (es. stesso prodotto in formato da 5kg, 10kg, 25kg) — sono varianti dello stesso prodotto
* I prodotti possono essere kit/bundle composti da più prodotti
* Molti prodotti sono ADR: hanno un numero ONU, una classe di pericolo e un gruppo di imballaggio (packing group). Il numero ONU è il dato master da cui derivano gli altri
* Ogni prodotto può avere schede di sicurezza (SDS) in più lingue, con versioni storiche
* Devo poter associare categorie (struttura gerarchica, una sola per prodotto) e tag (etichette libere, multiple) agli stessi prodotti. Le categorie servono per navigare il catalogo, i tag per cercare caratteristiche trasversali



### Magazzino



* Tenere traccia delle scorte per ogni variante di prodotto
* La giacenza non deve essere un campo statico: voglio uno storico di tutti i movimenti (carichi, scarichi, resi, rettifiche)
* Devo poter fare inventari fisici: conto i pezzi, il sistema confronta con la giacenza teorica e genera automaticamente le rettifiche necessarie
* In futuro il sistema dovrà integrarsi con il nostro sito WooCommerce, che usa lo stesso magazzino fisico ma è un canale di vendita separato. Non so quindi come tenere traccia delle giacenze in modo sincronizzato (per altro non conosco bene l'informatica dietro WooCommerce)



### Prezzi e listini



* I prezzi dipendono dal canale di vendita (sito, ordine diretto via email, dropshipping, agente) e dal tipo di cliente (end user, rivenditore, grossista, ecc.)
* Abbiamo un canale che chiamiamo "dropshipping" in cui il fornitore ci gira suoi clienti: per questi prodotti il fornitore ci consiglia un prezzo minimo e uno massimo di vendita
* I prezzi sono sempre espressi per unità di misura base (€/kg o €/litro), non per confezione
* Ci sono scaglioni di quantità: il prezzo cambia sopra certe soglie
* Ogni cliente ha un listino assegnato di default, modificabile sulla singola offerta



### Offerte



* Creare offerte ai clienti con più righe prodotto
* Ogni riga mostra: prodotto, confezione, quantità, costo di acquisto, range di prezzo consigliato, prezzo applicato, totale, margine
* Il sistema deve calcolare e mostrare il margine complessivo dell'offerta (€ e %)
* Le offerte hanno uno storico degli stati (bozza → inviata → accettata/rifiutata)
* Devono poter essere stampate (DOCX)
* Devo tenere lo storico di tutte le offerte inviate con relativo esito



### Sistema



* Gestione utenti con ruoli diversi (admin, commerciale, magazziniere, sola lettura)



\---



## Cosa non serve nel prototipo

* Gestione rete vendita con agenti e provvigioni
* Rubrica contatti multipli per ogni azienda
* Fatturazione



## Cosa potrebbe servire in futuro

* DDT e documenti di trasporto
* Tenere traccia di ordini di acquisto ai fornitori

